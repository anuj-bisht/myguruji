<select class='form-control' id='teacher' name='teacher_id'  onChange="filter_chapters();" required>
	<option value='0'>Select Teacher</option>
	<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value='<?php echo $teacher->id; ?>'><?php echo $teacher->teacher_name; ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH E:\xampp_latest\htdocs\tutorials\resources\views/admin/chapters/teachers.blade.php ENDPATH**/ ?>