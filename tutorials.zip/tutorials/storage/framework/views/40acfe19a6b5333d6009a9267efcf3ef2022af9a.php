<select class='form-control' id='chapter' name='chapter_id' required>
	<option value='0'>Select Chapter</option>
	<?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value='<?php echo $chapter->id; ?>'><?php echo $chapter->chapter_name; ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH E:\xampp_latest\htdocs\tutorials\resources\views/admin/chapters/chapters.blade.php ENDPATH**/ ?>